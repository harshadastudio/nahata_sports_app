import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:nahata_app/core/network/http_logged.dart' as http;
import 'package:nahata_app/bottombar/slotbook.dart';

import '../core/widgets/app_shimmer.dart';
import 'Custombottombar.dart';



class Viewgame extends StatefulWidget {
  final String locationName; // 👈 add t, required String locationNamehis line

  const Viewgame({Key? key, required this.locationName}) : super(key: key);

  @override
  State<Viewgame> createState() => _ViewgameState();
}

class _ViewgameState extends State<Viewgame>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;


  late Future<List<Sport>> _sportsFuture;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _scaleController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _fadeController.forward();
    _scaleController.forward();

    // 🔥 Fetch games by location (example: "Sinhgad Rd")
    _sportsFuture = Api_loc_Service.fetchSportsByLocation(widget.locationName);

    // _sportsFuture = Api_loc_Service.fetchSportsByLocation("Sinhgad Rd");
    // _sportsFuture = Api_loc_Service.fetchSportsByLocation("Gangadham Chowk");
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: const Icon(
              Icons.arrow_back_ios_new,
              color: Colors.black87,
              size: 18,
            ),
          ),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => CustomBottomNav()),
            );

          },
        ),
        title: const Text(
          'Book and Play',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        // actions: [
        //   IconButton(
        //     icon: Container(
        //       padding: const EdgeInsets.all(8),
        //       decoration: BoxDecoration(
        //         color: Colors.white,
        //         borderRadius: BorderRadius.circular(12),
        //         boxShadow: [
        //           BoxShadow(
        //             color: Colors.black.withOpacity(0.1),
        //             blurRadius: 10,
        //             offset: const Offset(0, 2),
        //           ),
        //         ],
        //       ),
        //       child: const Icon(
        //         Icons.notifications_outlined,
        //         color: Colors.black87,
        //         size: 18,
        //       ),
        //     ),
        //     onPressed: () {},
        //   ),
        //   const SizedBox(width: 16),
        // ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                Text(
                  'Games at ${widget.locationName}',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 25),
                // GridView.count(
                //   crossAxisCount: 2,
                //   shrinkWrap: true,
                //   physics: const NeverScrollableScrollPhysics(),
                //   mainAxisSpacing: 20,
                //   crossAxisSpacing: 20,
                //   childAspectRatio: 1.1,
                //   children: [
                //     _buildGameCard(
                //       'Basketball',
                //       '🏀',
                //       const LinearGradient(
                //         begin: Alignment.topLeft,
                //         end: Alignment.bottomRight,
                //         colors: [Color(0xFF64B5F6), Color(0xFF42A5F5)],
                //       ),
                //       0,
                //     ),
                //     _buildGameCard(
                //       'Cricket',
                //       '🏏',
                //       const LinearGradient(
                //         begin: Alignment.topLeft,
                //         end: Alignment.bottomRight,
                //         colors: [Color(0xFFFFB74D), Color(0xFFFF9800)],
                //       ),
                //       1,
                //     ),
                //     _buildGameCard(
                //       'Badminton',
                //       '🏸',
                //       const LinearGradient(
                //         begin: Alignment.topLeft,
                //         end: Alignment.bottomRight,
                //         colors: [Color(0xFF9575CD), Color(0xFF7E57C2)],
                //       ),
                //       2,
                //     ),
                //     _buildGameCard(
                //       'Pickleball',
                //       '🎾',
                //       const LinearGradient(
                //         begin: Alignment.topLeft,
                //         end: Alignment.bottomRight,
                //         colors: [Color(0xFFE57373), Color(0xFFEF5350)],
                //       ),
                //       3,
                //     ),
                //   ],
                // ),
                FutureBuilder<List<Sport>>(
                  future: _sportsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      // Same 2-column geometry as the grid below, so the tiles
                      // land where the placeholders already were.
                      return AppShimmer.sportsGrid();
                    }
                    else if (snapshot.hasError) {
                      return AnimatedSwitcher(
                        duration: const Duration(milliseconds: 700),
                        transitionBuilder: (child, animation) =>
                            ScaleTransition(scale: animation, child: child),
                        child: Column(
                          key: ValueKey('no_data'),
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.sentiment_dissatisfied_outlined,
                              color: Colors.grey[400],
                              size: 80,
                            ),
                            const SizedBox(height: 16),
                            const Text(
                              "No Entry Here",
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.black54,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      );
                    }

                    // else if (snapshot.hasError) {
                    //   return Center(
                    //     child: Text(
                    //       "Error: ${snapshot.error}",
                    //       style: const TextStyle(color: Colors.red),
                    //     ),
                    //   );
                    // } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    //   return const Center(child: Text("No sports found"));
                    // }

                    final sports = snapshot.data!;

                    return GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 20,
                        mainAxisSpacing: 20,
                        childAspectRatio: 1.1,
                      ),
                      itemCount: sports.length,
                      itemBuilder: (context, index) {
                        final sport = sports[index];
                        return _buildGameCard(sport, index);
                      },
                    );
                  },
                ),

                const SizedBox(height: 30),
                // _buildFeaturedSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
  Widget _buildGameCard(Sport sport, int index) {
    final String title = sport.name;
    final String imageUrl = sport.imageUrl;
    return TweenAnimationBuilder<double>(
      duration: Duration(milliseconds: 600 + (index * 100)),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.elasticOut,
      builder: (context, value, child) {
        return Transform.scale(
          scale: value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: Color(0xFF1A237E), // fallback color
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.blue.withOpacity(0.3),
                  blurRadius: 15,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      // 🔄 NEW API: forward resolved sportId & sportComplexId
                      builder: (_) => SlotBookingScreen(
                        game: title,
                        location: widget.locationName,
                        sportId: sport.id,
                        sportComplexId: sport.complexId,
                      ),
                    ),
                  );
                },
                // The grid fixes this card's height (childAspectRatio), so the
                // column has to fit whatever it is given: the padding is tight
                // enough for a two-line title, and the title itself is
                // Flexible so a long name or a large system text scale
                // ellipsises instead of overflowing the cell.
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(30),
                          child: imageUrl.isNotEmpty
                              ? Image.network(imageUrl, fit: BoxFit.cover)
                              : const Icon(Icons.sports, color: Colors.white, size: 30),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Flexible(
                        child: Text(
                          title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // Widget _buildGameCard(String title, String emoji, Gradient gradient, int index) {
  //   return TweenAnimationBuilder<double>(
  //     duration: Duration(milliseconds: 600 + (index * 100)),
  //     tween: Tween(begin: 0.0, end: 1.0),
  //     curve: Curves.elasticOut,
  //     builder: (context, value, child) {
  //       return Transform.scale(
  //         scale: value,
  //         child: GestureDetector(
  //           onTap: () {
  //             Navigator.push(
  //               context,
  //               MaterialPageRoute(
  //                 builder: (_) => slotbook(gameName: title), // pass game name
  //               ),
  //             );
  //           },
  //
  //           child: AnimatedContainer(
  //             duration: const Duration(milliseconds: 200),
  //             decoration: BoxDecoration(
  //               gradient: gradient,
  //               borderRadius: BorderRadius.circular(20),
  //               boxShadow: [
  //                 BoxShadow(
  //                   color: gradient.colors.first.withOpacity(0.3),
  //                   blurRadius: 15,
  //                   offset: const Offset(0, 8),
  //                 ),
  //               ],
  //             ),
  //             child: Material(
  //               color: Colors.transparent,
  //               child: InkWell(
  //                 borderRadius: BorderRadius.circular(20),
  //                 onTap: () {
  //                   Navigator.push(
  //                     context,
  //                     MaterialPageRoute(
  //                       builder: (_) => slotbook(gameName: title), // pass game name
  //                     ),
  //                   );
  //                 },
  //                 child: Container(
  //                   padding: const EdgeInsets.all(20),
  //                   child: Column(
  //                     mainAxisAlignment: MainAxisAlignment.center,
  //                     children: [
  //                       Container(
  //                         width: 60,
  //                         height: 60,
  //                         decoration: BoxDecoration(
  //                           color: Colors.white.withOpacity(0.2),
  //                           borderRadius: BorderRadius.circular(30),
  //                         ),
  //                         child: Center(
  //                           child: Text(
  //                             emoji,
  //                             style: const TextStyle(fontSize: 28),
  //                           ),
  //                         ),
  //                       ),
  //                       const SizedBox(height: 12),
  //                       Text(
  //                         title,
  //                         style: const TextStyle(
  //                           color: Colors.white,
  //                           fontSize: 16,
  //                           fontWeight: FontWeight.w600,
  //                         ),
  //                         textAlign: TextAlign.center,
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           ),
  //         ),
  //       );
  //     },
  //   );
  // }

  Widget _buildFeaturedSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Featured Activities',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 15),
        Container(
          height: 120,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF667eea), Color(0xFF764ba2)],
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF667eea).withOpacity(0.3),
                blurRadius: 15,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () {},
              child: const Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Tournament Week',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Join exciting tournaments and win prizes!',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.emoji_events,
                      color: Colors.white,
                      size: 40,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showGameDetails(String gameName) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25),
            topRight: Radius.circular(25),
          ),
        ),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 12),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    gameName,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Available time slots and booking details for $gameName',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 15,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Book Now',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Api_loc_Service {
  // 🔄 NEW API base
  static const String _apiBase = "https://api.nahatasports.com/api";

  // ---------------------- OLD API (commented out) ----------------------
  // static Future<List<Sport>> fetchSportsByLocation(String location) async {
  //   final uri = Uri.parse('https://nahatasports.com/sports_list');
  //   final response = await http.get(uri);
  //
  //   print("API response: ${response.body}");
  //
  //   if (response.statusCode == 200) {
  //     final Map<String, dynamic> jsonMap = json.decode(response.body);
  //
  //     if (!jsonMap.containsKey('data')) {
  //       throw Exception('No data found in API response');
  //     }
  //
  //     final availableKeys = jsonMap['data'].keys;
  //     print('Requested location: "$location"');
  //     print('Available keys: $availableKeys');
  //
  //     final matchedKey = availableKeys.firstWhere(
  //           (k) => k.toLowerCase().trim() == location.toLowerCase().trim(),
  //       orElse: () => throw Exception('No data for "$location"'),
  //     );
  //
  //     final List<dynamic> sportsList = jsonMap['data'][matchedKey];
  //
  //     return sportsList.map((e) => Sport.fromJson(e)).toList();
  //   } else {
  //     throw Exception('Failed to load sports');
  //   }
  // }

  // ---------------------- NEW API ----------------------
  /// Resolve a sports-complex id from its display name.
  static Future<int?> fetchComplexId(String location) async {
    final uri = Uri.parse(
        '$_apiBase/sports-complexes?status=Active&showOnFrontend=true&limit=50');
    final response = await http.get(uri, headers: {'Accept': 'application/json'});
    if (response.statusCode != 200) return null;

    final body = json.decode(response.body);
    final List complexes = body['data']?['sportsComplexes'] ?? [];
    for (final c in complexes) {
      if ((c['name'] ?? '').toString().toLowerCase().trim() ==
          location.toLowerCase().trim()) {
        return c['id'] is int ? c['id'] as int : int.tryParse('${c['id']}');
      }
    }
    return null;
  }

  /// Fetch every active court of a complex (handles pagination).
  static Future<List<dynamic>> _fetchAllCourts(int complexId) async {
    final List<dynamic> all = [];
    int page = 1;
    while (true) {
      final uri = Uri.parse(
          '$_apiBase/courts?sportComplexId=$complexId&status=Active&limit=100&page=$page');
      final response =
          await http.get(uri, headers: {'Accept': 'application/json'});
      if (response.statusCode != 200) break;

      final body = json.decode(response.body);
      final List data = body['data'] ?? [];
      all.addAll(data);

      final totalPages = body['pagination']?['totalPages'] ?? 1;
      if (page >= (totalPages is int ? totalPages : 1)) break;
      page++;
    }
    return all;
  }

  /// Build the distinct list of sports available at a location from /courts.
  static Future<List<Sport>> fetchSportsByLocation(String location) async {
    final complexId = await fetchComplexId(location);
    if (complexId == null) {
      throw Exception('No data for "$location"');
    }

    final courts = await _fetchAllCourts(complexId);

    // Distinct sports keyed by sportId, first court image (if any) used as icon.
    final Map<int, Sport> byId = {};
    for (final c in courts) {
      final sp = c['Sport'];
      if (sp == null || sp['id'] == null) continue;
      final id = sp['id'] is int ? sp['id'] as int : int.tryParse('${sp['id']}');
      if (id == null || byId.containsKey(id)) continue;
      byId[id] = Sport(
        id: id,
        name: (sp['name'] ?? 'Unknown').toString(),
        imageUrl: (c['image'] ?? '').toString(),
        complexId: complexId,
      );
    }

    return byId.values.toList();
  }
}

class Sport {
  final int? id;
  final int? complexId;
  final String name;
  final String imageUrl;

  Sport({
    this.id,
    this.complexId,
    required this.name,
    required this.imageUrl,
  });

  // ---------------------- OLD API mapping (commented out) ----------------------
  // factory Sport.fromJson(Map<String, dynamic> json) {
  //   return Sport(
  //     name: json['sport_name'] ?? 'Unknown',
  //     imageUrl: json['image'] ?? '',
  //   );
  // }
}
