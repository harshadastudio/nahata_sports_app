import '../../models/profile_model.dart';
import '../storage/profile_cache.dart';
import '../utils/app_logger.dart';
import 'app_session.dart';

/// Well-known permission slugs returned by `/auth/profile`.
///
/// Use these constants instead of bare strings so typos fail at compile time.
class AppPermissions {
  const AppPermissions._();

  static const String dashboard = 'user_dashboard';
  static const String logout = 'user_logout';
  static const String account = 'user_account';
  static const String viewSports = 'user_view_sports';
  static const String feedback = 'user_feedback';
  static const String myBookings = 'user_my_bookings';
  static const String myEventPass = 'user_my_event_pass';
  static const String studentsParents = 'user_students_parents';
  static const String entryPass = 'user_entry_pass';
  static const String attendanceSheet = 'user_attendance_sheet';
  static const String coachingEnquiries = 'user_coaching_enquiries';
}

/// Permission slugs granted to the `COACH` role, as returned by
/// `/auth/profile` and `/permissions/coach`.
///
/// These mirror the `COACH` block of the website's `roleMenuConfig.ts`
/// one-for-one, so the app and the web dashboard hide and show the same
/// sections for the same coach.
class CoachPermissions {
  const CoachPermissions._();

  static const String dashboard = 'coach_dashboard';

  /// Covers both My Students and Student Enrollments — the website gates both
  /// on this single slug.
  static const String students = 'coach_students';

  static const String schedule = 'coach_schedule';

  /// Covers the attendance sheet and the student pass scanner.
  static const String attendance = 'coach_attendance';

  static const String performance = 'coach_performance';
  static const String feesManagement = 'coach_fees_management';
  static const String feesApproval = 'coach_fees_approval';
  static const String coachingEnquiries = 'coach_coaching_enquiries';
  static const String notifications = 'coach_notifications';
  static const String logout = 'coach_logout';

  /// Not coach-specific — the website marks the profile entry `alwaysShow`, so
  /// it is never filtered out even when the slug is absent.
  static const String profile = 'profile';
}

/// Permission slugs granted to the `EMPLOYEE` role, as returned by
/// `/auth/profile` and `/permissions/employee`.
///
/// These mirror the `EMPLOYEE` block of the website's `roleMenuConfig.ts`
/// one-for-one, so the app and the web dashboard hide and show the same
/// sections for the same employee.
///
/// The six "operations" slugs at the bottom are also enforced **on the API**
/// by `employeePermission.js`, so hiding those entries is not merely cosmetic —
/// an ungranted employee gets a 403 from the server as well.
class EmployeePermissions {
  const EmployeePermissions._();

  static const String dashboard = 'employee_dashboard';
  static const String bookings = 'employee_bookings';
  static const String payments = 'employee_payments';
  static const String attendance = 'employee_attendance';
  static const String coaches = 'employee_coaches';
  static const String coachingEnquiries = 'employee_coaching_enquiries';
  static const String feesApproval = 'employee_fees_approval';
  static const String users = 'employee_users';
  static const String notifications = 'employee_notifications';

  // ── Complex-scoped operations modules. Each shows only the employee's own
  //    sports complex; the API enforces that, not the UI. ────────────────────
  static const String blockedSlots = 'employee_blocked_slots';
  static const String feesManagement = 'employee_fees_management';
  static const String sports = 'employee_sports';
  static const String courts = 'employee_courts';
  static const String slots = 'employee_slots';
  static const String batches = 'employee_batches';

  static const String logout = 'employee_logout';

  /// Not employee-specific — the website marks the profile entry `alwaysShow`,
  /// so it is never filtered out even when the slug is absent.
  static const String profile = 'profile';
}

/// Single source of truth for "may the current user do X?".
///
/// Permissions arrive with the profile; [sync] is called whenever the profile
/// changes so checks stay synchronous and allocation-free at call sites:
///
/// ```dart
/// if (PermissionService.instance.hasPermission(AppPermissions.dashboard)) { … }
/// ```
class PermissionService {
  PermissionService._();

  static final PermissionService instance = PermissionService._();

  Set<String> _permissions = <String>{};
  String _role = '';
  Map<String, Map<String, bool>> _matrix = const <String, Map<String, bool>>{};

  Set<String> get permissions => Set.unmodifiable(_permissions);

  /// The object-form permissions (`{"students": {"view": true}}`) when the
  /// backend sent them; empty for the legacy slug list.
  Map<String, Map<String, bool>> get matrix => Map.unmodifiable(_matrix);

  String get role => _role;

  bool get isLoaded => _permissions.isNotEmpty || _role.isNotEmpty;

  /// Refreshes the cached permission set from a profile.
  ///
  /// Also hands the profile to [AppSession] — this is the one call every
  /// sign-in path makes, so the session scope (role, assigned complex) stays
  /// in step with the permissions without a second wiring point.
  void sync(ProfileModel? profile) {
    AppSession.instance.adopt(profile);

    // Read back rather than using [profile] directly: the session carries
    // forward the permission matrix and assigned complex that a slimmer
    // `/auth/profile` payload leaves out.
    final effective = AppSession.instance.profile;
    _permissions = (effective?.permissions ?? const <String>[]).toSet();
    _role = effective?.roleKey ?? '';
    _matrix = effective?.permissionMatrix ?? const <String, Map<String, bool>>{};

    _traceMatrix();
  }

  /// Prints what the payload actually granted.
  ///
  /// The console's sidebar is built from this and nothing else, so "why is
  /// module X missing?" is answered here rather than by reading widget code.
  /// Module names and booleans only — no token, no identifier, nothing secret.
  void _traceMatrix() {
    if (!AppLogger.enabled) return;

    if (_matrix.isEmpty) {
      AppLogger.debug(
        'Permissions for role "$_role": no module matrix in the payload '
        '(${_permissions.length} legacy slugs) — console gating falls open',
        name: 'Permissions',
      );
      return;
    }

    final granted = <String>[];
    final denied = <String>[];
    for (final entry in _matrix.entries) {
      (entry.value['view'] == true ? granted : denied).add(entry.key);
    }
    granted.sort();
    denied.sort();

    AppLogger.debug(
      'Permissions for role "$_role" → viewable: '
      '${granted.isEmpty ? '(none)' : granted.join(', ')}'
      '${denied.isEmpty ? '' : ' | view:false: ${denied.join(', ')}'}',
      name: 'Permissions',
    );
  }

  /// Loads permissions from disk — used before the first profile fetch lands.
  Future<void> loadFromCache() async {
    final profile = await ProfileCache.instance.read();
    if (profile != null) {
      sync(profile);
      return;
    }
    _permissions = (await ProfileCache.instance.readPermissions()).toSet();
  }

  bool hasPermission(String permission) => _permissions.contains(permission);

  /// `can('students', 'view')` — the module/action form returned by
  /// `/auth/login`. Falls back to the flat `module.action` slug so a profile
  /// restored from an older cache answers identically. Never hard-codes a role.
  bool can(String module, String action) {
    final actions = _matrix[module];
    if (actions != null) return actions[action] ?? false;
    return _permissions.contains('$module.$action');
  }

  bool canView(String module) => can(module, 'view');
  bool canCreate(String module) => can(module, 'create');
  bool canEdit(String module) => can(module, 'edit');
  bool canDelete(String module) => can(module, 'delete');

  bool hasAny(Iterable<String> required) => required.any(_permissions.contains);

  bool hasAll(Iterable<String> required) =>
      required.every(_permissions.contains);

  bool hasRole(String role) => _role == role.toLowerCase();

  bool get isAdmin => _role == 'admin';
  bool get isComplexAdmin => _role == 'complex_admin';
  bool get isCoach => _role == 'coach';
  bool get isEmployee => _role == 'employee';
  bool get isSecurity => _role == 'security';
  bool get isUser => _role == 'user' || _role.isEmpty;

  void clear() {
    _permissions = <String>{};
    _role = '';
    _matrix = const <String, Map<String, bool>>{};
    AppSession.instance.clear();
  }
}
