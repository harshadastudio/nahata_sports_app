import 'package:flutter/material.dart';

import '../../data/repositories/employee_dashboard_repository_impl.dart';
import '../../domain/entities/employee_enquiry.dart';
import '../state/employee_enquiries_controller.dart';
import '../theme/employee_theme.dart';
import '../widgets/employee_forms.dart';
import '../widgets/employee_list_scaffold.dart';

/// Coaching Enquiries — log a walk-in, review, then approve and enroll.
class EmployeeEnquiriesPage extends StatefulWidget {
  const EmployeeEnquiriesPage({super.key});

  @override
  State<EmployeeEnquiriesPage> createState() => _EmployeeEnquiriesPageState();
}

class _EmployeeEnquiriesPageState extends State<EmployeeEnquiriesPage> {
  late final EmployeeEnquiriesController _controller =
      EmployeeEnquiriesController(EmployeeDashboardRepositoryImpl());
  final TextEditingController _search = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller.load();
  }

  @override
  void dispose() {
    _search.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Wrapped so the empty-state copy and the FAB track the controller.
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) => EmployeeListScaffold<EmployeeEnquiry>(
        title: 'Coaching enquiries',
        controller: _controller,
        subtitle: () => '${_controller.total} enquir'
            '${_controller.total == 1 ? 'y' : 'ies'}',
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _openForm(null),
          backgroundColor: EmployeeTokens.brand,
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add_rounded),
          label: const Text('Add enquiry'),
        ),
        filters: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            EmployeeSearchBar(
              controller: _search,
              hintText: 'Search by name, email or phone',
              onChanged: _controller.onSearchChanged,
              onClear: () => _controller.onSearchChanged(''),
            ),
            const SizedBox(height: EmployeeTokens.space3),
            EmployeeFilterChips<String>(
              values: EmployeeEnquiriesController.statuses,
              selected: _controller.status,
              labelOf: (s) => s,
              onChanged: _controller.setStatus,
            ),
          ],
        ),
        itemBuilder: (context, enquiry) => _enquiryCard(enquiry),
        emptyIcon: Icons.forum_outlined,
        emptyTitle: 'No enquiries found',
        emptyMessage: _controller.isFiltered
            ? 'Nothing matches these filters.'
            : 'Log a walk-in with "Add enquiry", or wait for one to arrive.',
      ),
    );
  }

  Widget _enquiryCard(EmployeeEnquiry enquiry) {
    return EmployeeCard(
      margin: const EdgeInsets.only(bottom: EmployeeTokens.space3),
      accentColor: EmployeeTokens.statusColor(enquiry.status),
      onTap: () => _openDetail(enquiry),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              EmployeeAvatar(initial: enquiry.initial, radius: 19),
              const SizedBox(width: EmployeeTokens.space3),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      enquiry.displayName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700,
                        color: EmployeeTokens.textDark,
                      ),
                    ),
                    if (enquiry.phone.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        enquiry.phone,
                        style: const TextStyle(
                          fontSize: 12,
                          color: EmployeeTokens.textMuted,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: EmployeeTokens.space2),
              EmployeeChip(label: enquiry.status, dense: true),
            ],
          ),
          const SizedBox(height: EmployeeTokens.space3),
          Row(
            children: [
              const Icon(
                Icons.groups_outlined,
                size: 13,
                color: EmployeeTokens.textMuted,
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  [
                    if (enquiry.batchDisplay != '—') enquiry.batchDisplay,
                    if (!enquiry.isAllSports && enquiry.sportName.isNotEmpty)
                      enquiry.sportName,
                  ].join(' · '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    color: EmployeeTokens.textBody,
                  ),
                ),
              ),
              if (enquiry.capacityLabel != null)
                Text(
                  enquiry.capacityLabel!,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: enquiry.isBatchFull
                        ? EmployeeTokens.danger
                        : EmployeeTokens.textMuted,
                  ),
                ),
            ],
          ),
          const SizedBox(height: EmployeeTokens.space2),
          Row(
            children: [
              Expanded(
                child: Text(
                  enquiry.submittedLabel,
                  style: const TextStyle(
                    fontSize: 11,
                    color: EmployeeTokens.textMuted,
                  ),
                ),
              ),
              if (enquiry.isEditable)
                IconButton(
                  onPressed: () => _openForm(enquiry),
                  icon: const Icon(Icons.edit_outlined, size: 18),
                  color: EmployeeTokens.textMuted,
                  tooltip: 'Edit',
                  visualDensity: VisualDensity.compact,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              const SizedBox(width: EmployeeTokens.space3),
              IconButton(
                onPressed: () => _delete(enquiry),
                icon: const Icon(Icons.delete_outline_rounded, size: 18),
                color: EmployeeTokens.danger,
                tooltip: 'Delete',
                visualDensity: VisualDensity.compact,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _delete(EmployeeEnquiry enquiry) async {
    final ok = await confirmEmployeeAction(
      context,
      title: 'Delete this enquiry?',
      message: enquiry.isApproved
          ? '${enquiry.displayName} is already enrolled — deleting the '
              'enquiry record does NOT undo that enrolment.'
          : 'The enquiry from ${enquiry.displayName} will be removed. This '
              'cannot be undone.',
      confirmLabel: 'Delete',
      destructive: true,
    );
    if (!ok || !mounted) return;

    final error = await _controller.delete(enquiry);
    if (!mounted) return;

    showEmployeeToast(
      context,
      error ?? 'Enquiry deleted',
      isError: error != null,
    );
  }

  Future<void> _openDetail(EmployeeEnquiry enquiry) {
    return showEmployeeSheet<void>(
      context: context,
      title: 'Enquiry #${enquiry.id}',
      subtitle: enquiry.displayName,
      builder: (context) => _EnquiryDetail(
        enquiry: enquiry,
        controller: _controller,
        onEdit: () {
          Navigator.of(context).pop();
          _openForm(enquiry);
        },
      ),
    );
  }

  Future<void> _openForm(EmployeeEnquiry? enquiry) {
    return showEmployeeSheet<void>(
      context: context,
      title: enquiry == null ? 'Add enquiry' : 'Edit enquiry',
      subtitle: enquiry?.displayName,
      builder: (context) => _EnquiryForm(
        enquiry: enquiry,
        controller: _controller,
      ),
    );
  }
}

class _EnquiryDetail extends StatefulWidget {
  const _EnquiryDetail({
    required this.enquiry,
    required this.controller,
    required this.onEdit,
  });

  final EmployeeEnquiry enquiry;
  final EmployeeEnquiriesController controller;
  final VoidCallback onEdit;

  @override
  State<_EnquiryDetail> createState() => _EnquiryDetailState();
}

class _EnquiryDetailState extends State<_EnquiryDetail> {
  late EmployeeEnquiry _enquiry = widget.enquiry;
  bool _busy = false;

  Future<void> _approve() async {
    final ok = await confirmEmployeeAction(
      context,
      title: 'Approve and enroll?',
      message: 'This enrolls ${_enquiry.displayName} in '
          '"${_enquiry.batchDisplay}" and opens their fee record as Pending. '
          'That fee still needs approving before their gate pass unlocks.',
      confirmLabel: 'Approve & enroll',
    );
    if (!ok || !mounted) return;

    setState(() => _busy = true);
    final error = await widget.controller.approve(_enquiry);
    if (!mounted) return;

    setState(() {
      _busy = false;
      if (error == null) _enquiry = _enquiry.copyWith(status: 'Approved');
    });

    showEmployeeToast(
      context,
      error ?? 'Approved — ${_enquiry.displayName} is enrolled',
      isError: error != null,
    );
  }

  Future<void> _changeStatus(String status) async {
    if (status == _enquiry.status) return;

    setState(() => _busy = true);
    final error = await widget.controller.changeStatus(_enquiry, status);
    if (!mounted) return;

    setState(() {
      _busy = false;
      if (error == null) _enquiry = _enquiry.copyWith(status: status);
    });

    showEmployeeToast(
      context,
      error ?? 'Status → $status',
      isError: error != null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final enquiry = _enquiry;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            EmployeeChip(label: enquiry.status),
            const Spacer(),
            if (enquiry.isEditable)
              TextButton.icon(
                onPressed: widget.onEdit,
                icon: const Icon(Icons.edit_outlined, size: 16),
                label: const Text('Edit'),
                style: TextButton.styleFrom(
                  foregroundColor: EmployeeTokens.brand,
                  visualDensity: VisualDensity.compact,
                ),
              ),
          ],
        ),
        const SizedBox(height: EmployeeTokens.space5),

        _section('Student'),
        EmployeeDetailRow(label: 'Name', value: enquiry.displayName),
        EmployeeDetailRow(label: 'Email', value: enquiry.email),
        EmployeeDetailRow(label: 'Phone', value: enquiry.phone),

        const SizedBox(height: EmployeeTokens.space4),
        _section('Enquiry'),
        EmployeeDetailRow(label: 'Sport', value: enquiry.sportDisplay),
        if (!enquiry.isAllSports) ...[
          EmployeeDetailRow(label: 'Batch', value: enquiry.batchDisplay),
          EmployeeDetailRow(
            label: 'Coach',
            value: enquiry.coachName.isEmpty ? '—' : enquiry.coachName,
          ),
        ],
        if (enquiry.feesLabel != null)
          EmployeeDetailRow(label: 'Batch fee', value: enquiry.feesLabel!),
        if (enquiry.capacityLabel != null)
          EmployeeDetailRow(
            label: 'Capacity',
            value: enquiry.capacityLabel!,
            valueColor:
                enquiry.isBatchFull ? EmployeeTokens.danger : null,
          ),
        if ((enquiry.referenceNumber ?? '').isNotEmpty)
          EmployeeDetailRow(
            label: 'Reference',
            value: enquiry.referenceNumber!,
            monospace: true,
          ),
        EmployeeDetailRow(label: 'Submitted', value: enquiry.submittedLabel),
        EmployeeDetailRow(
          label: 'Enrolled under',
          value: enquiry.enrolledUnderLabel,
        ),

        if ((enquiry.message ?? '').isNotEmpty) ...[
          const SizedBox(height: EmployeeTokens.space4),
          _section('Message'),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(EmployeeTokens.space3),
            decoration: BoxDecoration(
              color: EmployeeTokens.canvas,
              borderRadius: BorderRadius.circular(EmployeeTokens.radiusSm),
            ),
            child: Text(
              enquiry.message!,
              style: const TextStyle(
                fontSize: 13,
                height: 1.5,
                color: EmployeeTokens.textBody,
              ),
            ),
          ),
        ],

        const SizedBox(height: EmployeeTokens.space5),

        if (!enquiry.isActionable)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(EmployeeTokens.space3),
            decoration: BoxDecoration(
              color: EmployeeTokens.canvas,
              borderRadius: BorderRadius.circular(EmployeeTokens.radiusSm),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  enquiry.isApproved
                      ? Icons.check_circle_outline_rounded
                      : Icons.block_rounded,
                  size: 16,
                  color: EmployeeTokens.statusColor(enquiry.status),
                ),
                const SizedBox(width: EmployeeTokens.space2),
                Expanded(
                  child: Text(
                    enquiry.isApproved
                        ? 'Already approved — the student is enrolled. Their '
                            'fee is on the Fees Approval screen.'
                        : 'This enquiry was rejected and cannot be approved.',
                    style: const TextStyle(
                      fontSize: 11.5,
                      height: 1.4,
                      color: EmployeeTokens.textBody,
                    ),
                  ),
                ),
              ],
            ),
          )
        else ...[
          _section('Move without enrolling'),
          EmployeeDropdown<String>(
            value: employeeEnquiryManualStatuses.contains(enquiry.status)
                ? enquiry.status
                : null,
            items: employeeEnquiryManualStatuses,
            labelOf: (s) => s,
            placeholder: 'Change status',
            onChanged: _busy
                ? (String? _) {}
                : (value) => value == null ? null : _changeStatus(value),
          ),
          const SizedBox(height: EmployeeTokens.space4),

          FilledButton.icon(
            // A full batch is refused by the API with a 400, so the button is
            // disabled rather than left to fail.
            onPressed: _busy || (!enquiry.isAllSports && enquiry.isBatchFull)
                ? null
                : _approve,
            icon: _busy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.2,
                      color: Colors.white,
                    ),
                  )
                : const Icon(Icons.how_to_reg_rounded, size: 18),
            label: Text(
              !enquiry.isAllSports && enquiry.isBatchFull
                  ? 'Batch is full'
                  : 'Approve & enroll',
            ),
            style: FilledButton.styleFrom(
              backgroundColor: EmployeeTokens.success,
              minimumSize: const Size(double.infinity, 48),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(EmployeeTokens.radiusSm),
              ),
            ),
          ),
          const SizedBox(height: EmployeeTokens.space3),
          const Text(
            'Enrolling starts the student\'s fee record as Pending. It needs '
            'approving on the Fees Approval screen before their gate pass QR '
            'unlocks.',
            style: TextStyle(
              fontSize: 11.5,
              height: 1.45,
              color: EmployeeTokens.textMuted,
            ),
          ),
        ],
      ],
    );
  }

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: EmployeeTokens.space2),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 10.5,
          letterSpacing: 0.9,
          fontWeight: FontWeight.w700,
          color: EmployeeTokens.textMuted,
        ),
      ),
    );
  }
}

/// The **+ Add Enquiry** / pencil (edit) drawer.
class _EnquiryForm extends StatefulWidget {
  const _EnquiryForm({required this.enquiry, required this.controller});

  /// Null for a create.
  final EmployeeEnquiry? enquiry;
  final EmployeeEnquiriesController controller;

  @override
  State<_EnquiryForm> createState() => _EnquiryFormState();
}

class _EnquiryFormState extends State<_EnquiryForm> {
  late final TextEditingController _name =
      TextEditingController(text: widget.enquiry?.name ?? '');
  late final TextEditingController _email =
      TextEditingController(text: widget.enquiry?.email ?? '');
  late final TextEditingController _phone =
      TextEditingController(text: widget.enquiry?.phone ?? '');
  late final TextEditingController _message =
      TextEditingController(text: widget.enquiry?.message ?? '');

  late bool _isAllSports = widget.enquiry?.isAllSports ?? false;
  late int? _sportId = widget.enquiry?.sportId;
  late int? _batchId = widget.enquiry?.batchId;
  late int? _coachId = widget.enquiry?.coachId;

  bool _saving = false;
  String? _error;

  bool get _isEdit => widget.enquiry != null;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    _message.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty ||
        _email.text.trim().isEmpty ||
        _phone.text.trim().isEmpty) {
      setState(() => _error = 'Name, email and phone are required.');
      return;
    }

    final digits = _phone.text.trim().replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length != 10) {
      setState(() => _error = 'Phone must be exactly 10 digits.');
      return;
    }

    if (!_isAllSports && _batchId == null) {
      setState(() => _error = 'Pick a batch, or switch to All Sports.');
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    final draft = EmployeeEnquiryDraft(
      name: _name.text,
      email: _email.text,
      phone: _phone.text,
      isAllSports: _isAllSports,
      sportId: _isAllSports ? null : _sportId,
      batchId: _isAllSports ? null : _batchId,
      coachId: _isAllSports ? null : _coachId,
      message: _message.text,
    );

    final error = _isEdit
        ? await widget.controller.update(widget.enquiry!, draft)
        : await widget.controller.create(draft);

    if (!mounted) return;

    if (error != null) {
      setState(() {
        _saving = false;
        _error = error;
      });
      return;
    }

    Navigator.of(context).pop();
    showEmployeeToast(
      context,
      _isEdit ? 'Enquiry updated' : 'Enquiry created',
    );
  }

  @override
  Widget build(BuildContext context) {
    final sports = widget.controller.sports;
    final batches = widget.controller.batches;
    final coaches = widget.controller.coaches;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        EmployeeFormError(message: _error),

        EmployeeField(
          label: 'Student name',
          required: true,
          child: EmployeeTextField(
            controller: _name,
            hintText: 'e.g. Ravi Deshmukh',
          ),
        ),
        EmployeeField(
          label: 'Email',
          required: true,
          child: EmployeeTextField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            textCapitalization: TextCapitalization.none,
            hintText: 'student@example.com',
          ),
        ),
        EmployeeField(
          label: 'Phone',
          required: true,
          hint: 'Exactly 10 digits — no +91, no spaces.',
          child: EmployeeTextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            hintText: '9876543210',
          ),
        ),

        EmployeeSwitchField(
          label: 'All Sports',
          subtitle: 'File against the whole complex instead of one batch — '
              'every coach there can pick it up.',
          value: _isAllSports,
          onChanged: (value) => setState(() => _isAllSports = value),
        ),

        if (!_isAllSports) ...[
          EmployeeField(
            label: 'Sport',
            child: EmployeeDropdown<int>(
              value: _sportId,
              items: sports.map((s) => s.id).toList(),
              labelOf: (id) =>
                  sports.firstWhere((s) => s.id == id).displayName,
              placeholder: 'Derived from batch when left blank',
              onChanged: (value) => setState(() => _sportId = value),
            ),
          ),
          EmployeeField(
            label: 'Batch',
            required: true,
            child: EmployeeDropdown<int>(
              value: _batchId,
              items: batches.map((b) => b.id).toList(),
              labelOf: (id) =>
                  batches.firstWhere((b) => b.id == id).displayName,
              subtitleOf: (id) =>
                  batches.firstWhere((b) => b.id == id).feesLabel,
              placeholder: batches.isEmpty ? 'No batches yet' : 'Select a batch',
              onChanged: (value) => setState(() => _batchId = value),
            ),
          ),
          EmployeeField(
            label: 'Coach',
            hint: 'Optional — taken from the batch when left blank.',
            child: EmployeeDropdown<int>(
              value: _coachId,
              items: coaches.map((c) => c.id).toList(),
              labelOf: (id) =>
                  coaches.firstWhere((c) => c.id == id).displayName,
              placeholder: coaches.isEmpty ? 'No coaches yet' : 'From batch',
              onChanged: (value) => setState(() => _coachId = value),
            ),
          ),
        ],

        EmployeeField(
          label: 'Message',
          child: EmployeeTextField(
            controller: _message,
            maxLines: 3,
            hintText: 'What the walk-in is looking for',
          ),
        ),

        EmployeeSheetActions(
          saving: _saving,
          saveLabel: _isEdit ? 'Update enquiry' : 'Create enquiry',
          onSave: _save,
        ),
      ],
    );
  }
}
