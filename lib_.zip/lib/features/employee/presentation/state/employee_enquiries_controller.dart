import '../../core/employee_log.dart';
import '../../domain/entities/employee_coach.dart';
import '../../domain/entities/employee_enquiry.dart';
import '../../domain/entities/employee_master.dart';
import '../../domain/entities/employee_paged.dart';
import '../../domain/repositories/employee_dashboard_repository.dart';
import 'employee_list_controller.dart';

/// Coaching Enquiries — the staff queue.
///
/// Approve & Enroll is not a status change: the API creates the student,
/// enrols them in the batch and opens a `Pending` fee record inside one
/// transaction. The row is patched to `Approved` in place afterwards rather
/// than re-fetching, so the queue does not jump under someone who is working
/// down it. Create and edit, by contrast, always [refresh] — the new or
/// changed row carries joined names (sport, coach, batch) this side cannot
/// fill in on its own.
class EmployeeEnquiriesController
    extends EmployeeListController<EmployeeEnquiry> {
  EmployeeEnquiriesController(this._repository);

  final EmployeeDashboardRepository _repository;

  static const List<String> statuses = [
    'Pending',
    'Reviewed',
    'Contacted',
    'Approved',
    'Rejected',
  ];

  String? _status;
  String _search = '';

  List<EmployeeSport> _sports = const [];
  List<EmployeeBatch> _batches = const [];
  List<EmployeeCoach> _coaches = const [];
  bool _pickersLoaded = false;

  String? get status => _status;
  String get search => _search;

  List<EmployeeSport> get sports => _sports;
  List<EmployeeBatch> get batches => _batches;
  List<EmployeeCoach> get coaches => _coaches;

  /// Whether the Add Enquiry drawer can open at all — All Sports is always an
  /// option, but a single-sport enquiry needs at least one batch to pick.
  bool get canPickBatch => _batches.isNotEmpty;

  bool get isFiltered => _status != null || _search.trim().isNotEmpty;

  @override
  Future<EmployeePaged<EmployeeEnquiry>> fetchPage(int page) {
    return _repository.getEnquiries(
      page: page,
      limit: pageSize,
      status: _status,
      search: _search.trim().isEmpty ? null : _search.trim(),
    );
  }

  /// The three form dropdowns load once, alongside the first page. A failure
  /// here must not blank the queue — it only means the Add/Edit drawer opens
  /// with fewer choices.
  @override
  Future<void> onFirstPageLoaded() async {
    if (_pickersLoaded) return;
    _pickersLoaded = true;

    try {
      final results = await Future.wait([
        _repository.getSports(),
        _repository.getBatches(),
        _repository.getCoaches(limit: 200),
      ]);
      if (isDisposed) return;

      _sports = results[0] as List<EmployeeSport>;
      _batches = results[1] as List<EmployeeBatch>;
      _coaches = (results[2] as EmployeePaged<EmployeeCoach>).items;
      notify();
    } catch (e) {
      _pickersLoaded = false;
      EmployeeLog.failure('Enquiry pickers failed', error: e);
    }
  }

  void setStatus(String? value) {
    if (value == _status) return;
    _status = value;
    EmployeeLog.ui('Enquiry status filter → ${value ?? 'all'}');
    reload();
  }

  void onSearchChanged(String value) {
    if (value == _search) return;
    _search = value;
    notify();

    debounce(() {
      EmployeeLog.ui('Enquiry search → "${_search.trim()}"');
      load();
    });
  }

  void clearFilters() {
    cancelDebounce();
    if (!isFiltered) return;
    _status = null;
    _search = '';
    reload();
  }

  /// Approves and enrols. Returns null on success, else the server's message —
  /// which is the useful one here: it names the batch that was full or says the
  /// enquiry was already settled.
  Future<String?> approve(EmployeeEnquiry enquiry) async {
    try {
      await _repository.approveEnquiry(enquiry.id);
      replaceItem(
        (e) => e.id == enquiry.id,
        (e) => e.copyWith(status: 'Approved', updatedAt: DateTime.now()),
      );
      return null;
    } catch (e) {
      return reportFailure('Enquiry approve failed', e);
    }
  }

  /// The **+ Add Enquiry** drawer. Re-loads afterwards: the new row carries
  /// joined sport/batch/coach names this side cannot fill in, and a fresh
  /// student may have just been auto-registered.
  Future<String?> create(EmployeeEnquiryDraft draft) async {
    try {
      await _repository.createEnquiry(draft);
      await refresh();
      return null;
    } catch (e) {
      return reportFailure('Enquiry create failed', e);
    }
  }

  /// The pencil (edit). Refused by the API once the enquiry is Approved.
  Future<String?> update(EmployeeEnquiry enquiry, EmployeeEnquiryDraft draft) async {
    try {
      final updated = await _repository.updateEnquiry(enquiry.id, draft);
      if (updated != null) {
        replaceItem((e) => e.id == enquiry.id, (_) => updated);
      } else {
        await refresh();
      }
      return null;
    } catch (e) {
      return reportFailure('Enquiry update failed', e);
    }
  }

  /// Moves the enquiry along without enrolling anybody. `Approved` is never
  /// sent here — reaching it goes through [approve], which does far more than
  /// flip the flag.
  Future<String?> changeStatus(EmployeeEnquiry enquiry, String status) async {
    final previous = enquiry.status;
    replaceItem(
      (e) => e.id == enquiry.id,
      (e) => e.copyWith(status: status, updatedAt: DateTime.now()),
    );

    try {
      await _repository.updateEnquiryStatus(enquiry.id, status);
      return null;
    } catch (e) {
      replaceItem((e) => e.id == enquiry.id, (e) => e.copyWith(status: previous));
      return reportFailure('Enquiry status update failed', e);
    }
  }

  /// The bin. Soft-deletes server-side and does not undo an enrolment an
  /// earlier approval already produced.
  Future<String?> delete(EmployeeEnquiry enquiry) async {
    try {
      await _repository.deleteEnquiry(enquiry.id);
      removeItem((e) => e.id == enquiry.id);
      return null;
    } catch (e) {
      return reportFailure('Enquiry delete failed', e);
    }
  }
}
