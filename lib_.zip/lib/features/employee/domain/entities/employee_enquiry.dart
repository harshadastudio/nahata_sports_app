import 'employee_formats.dart';

/// One batch the student is ACTUALLY enrolled in, from an enquiry's
/// `enrolments[]`.
///
/// Distinct from the enquiry's own [EmployeeEnquiry.batchName] /
/// [EmployeeEnquiry.sportName], which is only what was *asked for*. A student
/// can train under several coaches across several sports, so this list is
/// empty until at least one approval has gone through — including approvals
/// other coaches gave the same **All Sports** enquiry.
class EmployeeEnquiryEnrolment {
  const EmployeeEnquiryEnrolment({
    this.batchName = '',
    this.sportName = '',
    this.coachName = '',
    this.status = '',
  });

  final String batchName;
  final String sportName;
  final String coachName;
  final String status;

  String get label => [
        if (sportName.isNotEmpty) sportName,
        if (batchName.isNotEmpty) batchName,
      ].join(' · ');

  @override
  String toString() => 'EmployeeEnquiryEnrolment($label, $status)';
}

/// A coaching enquiry in the staff queue, from `GET /coaching-enquiries/all`.
///
/// A prospect submits one publicly, or the desk logs one for a walk-in via
/// **+ Add Enquiry**; the desk reviews it and, when the batch has room,
/// approves it. **Approving is not a status change** — it creates the
/// student (or reuses their account), enrolls them in the batch and opens a
/// `Pending` fee record, all inside one transaction. That fee then needs its
/// own approval on the Fees Approval screen before the student's gate pass
/// unlocks.
class EmployeeEnquiry {
  const EmployeeEnquiry({
    required this.id,
    this.name = '',
    this.email = '',
    this.phone = '',
    this.sportId,
    this.sportName = '',
    this.batchId,
    this.batchName = '',
    this.batchFees,
    this.batchMaxStudents,
    this.batchCurrentStudents,
    this.coachId,
    this.coachName = '',
    this.isAllSports = false,
    this.status = 'Pending',
    this.message,
    this.referenceNumber,
    this.enrolments = const [],
    this.createdAt,
    this.updatedAt,
  });

  final int id;

  /// Resolved from the linked account when the enquiry came from a signed-in
  /// user, else the free-text name the public form (or the desk) captured.
  final String name;
  final String email;
  final String phone;

  final int? sportId;
  final String sportName;

  final int? batchId;
  final String batchName;
  final num? batchFees;

  /// Null when the row did not carry capacity — which is different from "the
  /// batch has no cap", so [isBatchFull] answers false rather than guessing.
  final int? batchMaxStudents;
  final int? batchCurrentStudents;

  final int? coachId;
  final String coachName;

  /// True means the enquiry was filed against the whole complex with no
  /// sport / batch / coach — every coach there sees it, and each can assign
  /// their own batch and enrol the same student. It is never auto-closed by
  /// one approval; it stays open until the status is changed by hand.
  final bool isAllSports;

  /// `Pending` | `Reviewed` | `Contacted` | `Approved` | `Rejected`.
  final String status;

  final String? message;
  final String? referenceNumber;

  /// What the student is ACTUALLY enrolled in — can span several sports and
  /// coaches, and is empty until at least one approval has landed.
  final List<EmployeeEnquiryEnrolment> enrolments;

  final DateTime? createdAt;
  final DateTime? updatedAt;

  String get displayName => name.trim().isEmpty ? 'Enquiry #$id' : name.trim();

  String get initial =>
      displayName.trim().isEmpty ? '?' : displayName.trim()[0].toUpperCase();

  /// `All Sports` when the enquiry carries no single sport, else the sport
  /// name — falling back to an em dash rather than a blank line.
  String get sportDisplay {
    if (isAllSports) return 'All Sports';
    return sportName.isEmpty ? '—' : sportName;
  }

  String get batchDisplay {
    if (isAllSports) return 'All Sports';
    return batchName.isEmpty ? '—' : batchName;
  }

  bool get isApproved => status.toLowerCase() == 'approved';
  bool get isRejected => status.toLowerCase() == 'rejected';

  /// Whether Approve & Enroll is still on the table. A settled enquiry is not
  /// re-approvable — the API answers 400.
  bool get isActionable => !isApproved && !isRejected;

  /// Approved enquiries cannot be edited — the API answers 400, because an
  /// approval already produced a User, a Student and a batch enrolment that
  /// editing here would not move.
  bool get isEditable => !isApproved;

  /// True only when the row actually reported both numbers and the batch is
  /// at or over capacity. The API refuses the enrollment in that case, so the
  /// button is disabled rather than left to fail.
  bool get isBatchFull {
    final max = batchMaxStudents;
    final current = batchCurrentStudents;
    if (max == null || current == null) return false;
    return current >= max;
  }

  /// `12/20 enrolled`, or null when capacity is unknown.
  String? get capacityLabel {
    final max = batchMaxStudents;
    final current = batchCurrentStudents;
    if (max == null || current == null) return null;
    return '$current/$max enrolled';
  }

  String? get feesLabel => batchFees == null ? null : formatRupees(batchFees);

  String get submittedLabel => formatDateTime(createdAt);

  /// What the ENROLLED UNDER column shows — the joined batches, or a note
  /// that nothing has been approved yet.
  String get enrolledUnderLabel =>
      enrolments.isEmpty ? 'Not enrolled yet' : enrolments.map((e) => e.label).join(', ');

  EmployeeEnquiry copyWith({String? status, DateTime? updatedAt}) {
    return EmployeeEnquiry(
      id: id,
      name: name,
      email: email,
      phone: phone,
      sportId: sportId,
      sportName: sportName,
      batchId: batchId,
      batchName: batchName,
      batchFees: batchFees,
      batchMaxStudents: batchMaxStudents,
      batchCurrentStudents: batchCurrentStudents,
      coachId: coachId,
      coachName: coachName,
      isAllSports: isAllSports,
      status: status ?? this.status,
      message: message,
      referenceNumber: referenceNumber,
      enrolments: enrolments,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() => 'EmployeeEnquiry($id, $displayName, $status)';
}

/// The five statuses a status change may set. `Approved` is deliberately
/// excluded — reaching it goes through Approve & Enroll, which does far more
/// than flip the flag; see [EmployeeEnquiry.isActionable].
const List<String> employeeEnquiryManualStatuses = [
  'Pending',
  'Reviewed',
  'Contacted',
  'Rejected',
];

/// The fields the Add / Edit Enquiry drawer writes.
///
/// **All Sports** — when [isAllSports] is true, [sportId], [batchId] and
/// [coachId] are omitted entirely: the enquiry is filed against the whole
/// complex instead of one batch.
class EmployeeEnquiryDraft {
  const EmployeeEnquiryDraft({
    required this.name,
    required this.email,
    required this.phone,
    this.sportId,
    this.batchId,
    this.coachId,
    this.message,
    this.isAllSports = false,
  });

  final String name;
  final String email;
  final String phone;
  final int? sportId;
  final int? batchId;
  final int? coachId;
  final String? message;
  final bool isAllSports;

  /// Shared by create and edit — the edit route documents every field as
  /// optional and only changes what is sent, which this already satisfies
  /// since every key here carries a real value.
  Map<String, dynamic> toBody() => {
        'name': name.trim(),
        'email': email.trim(),
        // The API requires exactly 10 digits, no `+91` and no spaces.
        'phone': phone.trim().replaceAll(RegExp(r'[^0-9]'), ''),
        if (isAllSports) 'isAllSports': true,
        if (!isAllSports && sportId != null) 'sportId': sportId,
        if (!isAllSports && batchId != null) 'batchId': batchId,
        if (!isAllSports && coachId != null) 'coachId': coachId,
        'message': (message ?? '').trim().isEmpty ? null : message!.trim(),
      };
}
